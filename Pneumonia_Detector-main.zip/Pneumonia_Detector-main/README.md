# Pneumonia_Detector 
### This Repository is detailed task:
- Visualization
- Preprocessing
- Modeling
- Deployment

## Sample Prediction:
![alt text](https://github.com/obaid001/Pneumonia_Detector/blob/main/samp.jpg?raw=true)

## Made by:
- Mohammad Obaid
- Mayank Singh
- Aniket Singh
- Krishna Kumar
